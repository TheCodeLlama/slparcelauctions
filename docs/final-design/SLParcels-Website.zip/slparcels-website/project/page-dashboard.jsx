// page-dashboard.jsx
function DashboardPage({ setPage, setAuctionId }) {
  const D = window.SLP_DATA;
  const [tab, setTab] = React.useState('bidding');
  const open = (id) => { setAuctionId(id); setPage('auction'); };

  return (
    <div className="page container" style={{ padding: '24px 24px 80px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 24, gap: 16 }}>
        <div>
          <div style={{ fontSize: 12, color: 'var(--fg-subtle)', marginBottom: 4 }}>
            <a className="muted" onClick={() => setPage('home')} style={{ cursor: 'pointer' }}>Home</a> / Dashboard
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 700, letterSpacing: '-0.02em', margin: 0 }}>My activity</h1>
        </div>
        <Btn variant="primary" onClick={() => setPage('create')}><Icons.Plus size={14} /> List a parcel</Btn>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
        {[
          ['Active bids', '7', 'var(--brand)'],
          ['Watching', '14', 'var(--info)'],
          ['Won this month', '3', 'var(--success)'],
          ['L$ at stake', '3,400', 'var(--fg)'],
        ].map(([k, v, c]) => (
          <div key={k} className="card" style={{ padding: 16 }}>
            <div style={{ fontSize: 11.5, color: 'var(--fg-subtle)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>{k}</div>
            <div style={{ fontSize: 24, fontWeight: 700, marginTop: 6, color: c, letterSpacing: '-0.02em' }}>{v}</div>
          </div>
        ))}
      </div>

      <div style={{ borderBottom: '1px solid var(--border)', display: 'flex', gap: 4, marginBottom: 20 }}>
        {[['bidding', 'Bidding (7)'], ['watching', 'Watching (14)'], ['won', 'Won (3)'], ['selling', 'Selling (2)']].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className="btn btn--ghost"
            style={{ borderRadius: 0, padding: '10px 14px', fontSize: 13.5,
              borderBottom: '2px solid ' + (tab === k ? 'var(--brand)' : 'transparent'),
              color: tab === k ? 'var(--fg)' : 'var(--fg-muted)', marginBottom: -1 }}>{l}</button>
        ))}
      </div>

      <div className="card" style={{ overflow: 'hidden' }}>
        <div style={{ padding: '10px 18px', display: 'grid', gridTemplateColumns: '60px 1fr 140px 140px 140px 120px 36px', fontSize: 11.5, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--fg-subtle)', borderBottom: '1px solid var(--border)', background: 'var(--bg-subtle)' }}>
          <div></div><div>Parcel</div><div>Your bid</div><div>Top bid</div><div>Status</div><div>Ends</div><div></div>
        </div>
        {D.AUCTIONS.slice(0, 7).map((p, i) => {
          const status = i === 0 ? 'Top bidder' : i === 1 ? 'Outbid' : i === 2 ? 'Top bidder' : i === 3 ? 'Outbid' : 'Top bidder';
          const yourBid = p.currentBid - (i % 2 === 1 ? 250 : 0);
          return (
            <div key={p.id} onClick={() => open(p.id)} style={{ padding: '12px 18px', display: 'grid', gridTemplateColumns: '60px 1fr 140px 140px 140px 120px 36px', alignItems: 'center', fontSize: 13.5, borderTop: i === 0 ? 'none' : '1px solid var(--border-subtle)', cursor: 'pointer' }}
                 onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-subtle)'}
                 onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}>
              <div style={{ width: 48, borderRadius: 6, overflow: 'hidden' }}>
                <ParcelImage parcel={p} ratio="1/1" showSave={false} />
              </div>
              <div>
                <div style={{ fontWeight: 500, marginBottom: 1 }}>{p.title}</div>
                <div style={{ fontSize: 11.5, fontFamily: 'var(--font-mono)', color: 'var(--fg-subtle)' }}>{p.coords}</div>
              </div>
              <div className="tabular bold"><L amount={yourBid} /></div>
              <div className="tabular"><L amount={p.currentBid} /></div>
              <div>
                <Badge tone={status === 'Top bidder' ? 'success' : 'danger'} dot>{status}</Badge>
              </div>
              <div className="tabular" style={{ color: p.minutesLeft < 60 ? 'var(--danger)' : 'var(--fg-muted)', fontWeight: 500 }}>
                <Countdown minutes={p.minutesLeft} compact />
              </div>
              <Icons.ChevronRight size={14} style={{ color: 'var(--fg-faint)' }} />
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.DashboardPage = DashboardPage;
