// app.jsx — root, routing, theme + tweaks

function applyTweaks(t) {
  const root = document.documentElement;
  root.dataset.theme = t.dark ? 'dark' : 'light';
  // Brand hue
  const h = t.primaryHue;
  const brand = `hsl(${h}, 78%, 50%)`;
  const brandHover = `hsl(${h}, 78%, 44%)`;
  const brandSoft = t.dark ? `hsla(${h}, 78%, 55%, 0.14)` : `hsl(${h}, 100%, 96%)`;
  const brandBorder = t.dark ? `hsla(${h}, 78%, 55%, 0.32)` : `hsl(${h}, 75%, 86%)`;
  root.style.setProperty('--brand', brand);
  root.style.setProperty('--brand-hover', brandHover);
  root.style.setProperty('--brand-soft', brandSoft);
  root.style.setProperty('--brand-border', brandBorder);
  // Radii
  const r = t.radius;
  root.style.setProperty('--r-sm', Math.max(2, r * 0.6) + 'px');
  root.style.setProperty('--r-md', r + 'px');
  root.style.setProperty('--r-lg', (r + 4) + 'px');
  root.style.setProperty('--r-xl', (r + 8) + 'px');
  // Density (1-10) → padding scale
  const d = t.density;
  const headerH = 50 + (10 - d) * 1.2;
  root.style.setProperty('--header-h', headerH + 'px');
}

function App() {
  const [tweaks, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  const [page, setPage] = React.useState('home');
  const [auctionId, setAuctionId] = React.useState('a0');

  React.useEffect(() => { applyTweaks(tweaks); }, [tweaks]);
  React.useEffect(() => { window.scrollTo(0, 0); }, [page, auctionId]);

  const pageProps = { setPage, setAuctionId, cardLayout: tweaks.cardLayout };

  return (
    <div className="app">
      <Header
        page={page}
        setPage={setPage}
        openSearch={() => setPage('browse')}
        headerStyle={tweaks.headerStyle}
      />
      {page === 'home' && <HomePage {...pageProps} />}
      {page === 'browse' && <BrowsePage {...pageProps} />}
      {page === 'auction' && <AuctionPage auctionId={auctionId} {...pageProps} />}
      {page === 'escrow' && <EscrowPage {...pageProps} />}
      {page === 'wallet' && <WalletPage {...pageProps} />}
      {page === 'dashboard' && <DashboardPage {...pageProps} />}
      {page === 'create' && <CreatePage {...pageProps} />}
      <Footer />

      <TweaksPanel>
        <TweakSection label="Appearance" />
        <TweakToggle label="Dark mode" value={tweaks.dark} onChange={(v) => setTweak('dark', v)} />
        <TweakSlider label="Accent hue" value={tweaks.primaryHue} min={0} max={360} unit="°" onChange={(v) => setTweak('primaryHue', v)} />
        <TweakSlider label="Card radius" value={tweaks.radius} min={0} max={20} unit="px" onChange={(v) => setTweak('radius', v)} />
        <TweakSlider label="UI density" value={tweaks.density} min={1} max={10} onChange={(v) => setTweak('density', v)} />

        <TweakSection label="Layout" />
        <TweakRadio label="Auction card" value={tweaks.cardLayout}
          options={['standard', 'detailed', 'compact']}
          onChange={(v) => setTweak('cardLayout', v)} />
        <TweakRadio label="Header style" value={tweaks.headerStyle}
          options={['default', 'minimal', 'bold']}
          onChange={(v) => setTweak('headerStyle', v)} />

        <TweakSection label="Content" />
        <TweakToggle label="Trust badges" value={tweaks.showTrustBadges} onChange={(v) => setTweak('showTrustBadges', v)} />

        <TweakSection label="Jump to page" />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
          {[['home','Home'],['browse','Browse'],['auction','Auction'],['escrow','Escrow'],['wallet','Wallet'],['dashboard','My bids'],['create','List parcel']].map(([k,l]) => (
            <button key={k} onClick={() => setPage(k)}
              style={{
                padding: '6px 8px', borderRadius: 6, fontSize: 11.5,
                border: '1px solid ' + (page === k ? 'var(--brand)' : 'rgba(0,0,0,.1)'),
                background: page === k ? 'var(--brand)' : 'rgba(255,255,255,.6)',
                color: page === k ? 'white' : 'inherit',
                cursor: 'pointer', textAlign: 'left',
              }}>{l}</button>
          ))}
        </div>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
